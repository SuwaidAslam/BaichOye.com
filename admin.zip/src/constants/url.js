export const SERVER_URL = 'http://localhost:5000/';
export const STATIC_FILES_URL = SERVER_URL + 'resources/';